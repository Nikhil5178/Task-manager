const jwt = require('jsonwebtoken');
const users = {}; // In-memory user store for demo

exports.registerUser = (req, res) => {
  const { username, password } = req.body;
  if (users[username]) return res.status(400).json({ error: 'User exists' });
  users[username] = password;
  res.status(201).json({ message: 'User registered' });
};

exports.loginUser = (req, res) => {
  const { username, password } = req.body;
  if (users[username] !== password) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ id: username }, process.env.JWT_SECRET);
  res.json({ token });
};
