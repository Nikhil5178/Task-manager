import React from 'react';
function App() {
  return <h1 className="text-2xl text-center mt-10">Task Manager App</h1>;
}
export default App;
